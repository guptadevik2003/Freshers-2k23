const Jimp = require('jimp')
const fs = require('fs')

// ttf converted to fnt using https://ttf2fnt.com

async function editImage({ imagePath, memberName, committeeName, subCommittees, savePath }){
    
    // Member Image Size
    let memberImageSize = 300
    
    // Converting Square Member Image to Circle using circleMask.png
    let circleMask = (await Jimp.read('CircleMask.png')).resize(memberImageSize, memberImageSize)
    let userImage = (await Jimp.read(imagePath)).resize(memberImageSize, memberImageSize).mask(circleMask, 0, 0)

    // Loading Fonts
    let font24 = await Jimp.loadFont('font24.fnt') // subCommittee
    let font32 = await Jimp.loadFont('font32.fnt') // committeeName
    let font48 = await Jimp.loadFont('font48.fnt') // memberName

    // Loading IdTemplate.png
    let IdTemplate = await Jimp.read('IdTemplate.png')
    
    // Pasting Circle Member Image to IdTemplate
    IdTemplate.composite(userImage, 146, 176)
    
    // Pasting memberName to IdTemplate
    IdTemplate.print(
        font48,                                           // Font Size
        (591 - Jimp.measureText(font48, memberName)) / 2, // Centering the text
        543,                                              // Vertical Position
        memberName                                        // Actual text
    )
    
    // Pasting committeeName to IdTemplate
    IdTemplate.print(
        font32,
        (591 - Jimp.measureText(font32, committeeName)) / 2,
        654,
        committeeName
    )

    // Checking if Member has any subCommittee
    if(subCommittees.length){
        let subPos = 743 // Vertical Position

        // Editing all subCommittees
        subCommittees.forEach(subCommitteeName => {

            // Pasting subCommitteeName to IdTemplate
            IdTemplate.print(
                font24,
                (591 - Jimp.measureText(font24, subCommitteeName)) / 2,
                subPos,
                subCommitteeName
            )

            // Incrementing Vertical Position for next subCommitteeName
            subPos = subPos + 60

        })

    }
    
    // Saving the Edited ID Card
    IdTemplate.write(savePath)
    console.log(`Saved ${memberName} from ${committeeName} to ${savePath}`)

}



// Main Code
let CommitteeDataFolder = fs.readdirSync('./CommitteeData')

CommitteeDataFolder.forEach(async committee => {

    let CommitteeFolder = fs.readdirSync(`./CommitteeData/${committee}`)
    
    CommitteeFolder.forEach(async member => {
        
        // Getting memberName from memberImage.jpg
        let name = member.split('.')[0]

        let anchors = [
            'Aakriti Solanki',
            'Bhaskar Singh',
            'Parikshit',
            'Parkhi Sharma',
            'Pragya Karnwal',
            'Riya Chand',
            'Saumya Mishra',
            'Vedansh Goel',
        ]

        let backstage = [
            'Aditi Joshi',
            'Garvita Arora',
            'Harshita Puri',
            'Mohd Azim',
            'Nikita Kandpal',
            'Shrishti Singh',
            'Simran Sachdeva',
        ]

        // Adding subCommittees for Members (can be multiple)
        let subCommitteeData = []
        if(anchors.includes(name)) subCommitteeData = ['ANCHOR']
        if(backstage.includes(name)) subCommitteeData = ['BACKSTAGE TEAM']

        // Calling Edit Function for all Members
        await editImage({
            imagePath: `./CommitteeData/${committee}/${member}`,
            memberName: name.toUpperCase(),
            committeeName:`${committee.toUpperCase()} COMMITTEE`,
            savePath: `./FinalData/${committee}/${name}.png`,
            subCommittees: subCommitteeData
        })

    })

})
